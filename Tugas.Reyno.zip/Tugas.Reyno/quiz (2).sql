-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2024 at 03:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `ID` int(11) NOT NULL,
  `QuizID` varchar(255) NOT NULL,
  `nomor_soal` int(11) NOT NULL,
  `Question` text NOT NULL,
  `OptionA` text NOT NULL,
  `OptionB` text NOT NULL,
  `OptionC` text NOT NULL,
  `OptionD` text NOT NULL,
  `CorrectAnswer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`ID`, `QuizID`, `nomor_soal`, `Question`, `OptionA`, `OptionB`, `OptionC`, `OptionD`, `CorrectAnswer`) VALUES
(1, '901', 1, 'Kapan agung lahir?', 'G lahir', '17 Agustus 1945', '12 Mei 1948', '13 Agustus 2006', '13 Agustus 2006'),
(2, '344', 1, 'tes', 'ES', 'fd', 'as', 'SD', 'SD'),
(3, '901', 2, 'Kapan agung lahir2?', 'G lahir', '17 Agustus 1945', '12 Mei 1948', '13 Agustus 2006', '13 Agustus 2006'),
(4, '901', 3, 'Kapan agung lahir3?', 'G lahir', '17 Agustus 1945', '12 Mei 1948', '13 Agustus 2006', '13 Agustus 2006'),
(5, 'YEbFe694', 1, 'dsad', 'sadasdsad', 'sdsds', 'dsadsa', 'dasdsads', 'dasdsads'),
(6, 'YEbFe694', 1, 'ccxzczsd', 'sdsd', 'sdsdsds', 'dsadsd', 'sadsds', 'sdsdsds'),
(7, 'p6ponlot', 1, 'dsdsadasd', 'asdasd', 'sadsdsa', 'dsadsadsadsa', 'dsadsd', 'asdasd'),
(8, 'p6ponlot', 2, 'dsdsadsadsadsa', 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd'),
(9, 'lZjMGfTO', 1, 'assas', 'asas', 'asas', 'asasas', 'asas', 'asas');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `absen` int(11) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `absen`, `is_admin`, `nama`, `password`, `marks`) VALUES
(1, 1, 0, 'agung', '', 2),
(2, 90, 1, 'sss', 'kepo', 1),
(3, 10, 0, 'kepo', 'kepo', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `absen` (`absen`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
